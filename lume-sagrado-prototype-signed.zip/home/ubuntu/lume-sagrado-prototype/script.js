// Carrinho de compras
let carrinho = [];

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    // Configurar data mínima para agendamento (hoje)
    const hoje = new Date().toISOString().split('T')[0];
    document.getElementById('data-agendamento').min = hoje;
    
    // Event listeners para modais
    setupModals();
    
    // Event listeners para agendamento
    setupAgendamento();
    
    // Event listener para finalizar compra
    document.getElementById('finalizar-compra').addEventListener('click', finalizarCompra);
    
    // Atualizar contador do carrinho
    updateCarrinhoCount();
});

// Configurar modais
function setupModals() {
    const modals = document.querySelectorAll('.modal');
    const closes = document.querySelectorAll('.close');
    
    // Abrir modal do carrinho
    document.getElementById('carrinho-link').addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('carrinho-modal').style.display = 'block';
        updateCarrinhoDisplay();
    });
    
    // Fechar modais
    closes.forEach(close => {
        close.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });
    
    // Fechar modal clicando fora
    window.addEventListener('click', function(e) {
        modals.forEach(modal => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
}

// Configurar agendamento
function setupAgendamento() {
    const btnsAgendar = document.querySelectorAll('.btn-agendar');
    
    btnsAgendar.forEach(btn => {
        btn.addEventListener('click', function() {
            const service = this.getAttribute('data-service');
            document.getElementById('servico-select').value = service;
            document.getElementById('agendamento-modal').style.display = 'block';
        });
    });
    
    // Formulário de agendamento
    document.getElementById('agendamento-form').addEventListener('submit', function(e) {
        e.preventDefault();
        processarAgendamento();
    });
}

// Alterar quantidade de produto
function changeQuantity(productId, change) {
    const qtyElement = document.getElementById(`qty-${productId}`);
    let currentQty = parseInt(qtyElement.textContent);
    let newQty = currentQty + change;
    
    if (newQty < 1) newQty = 1;
    if (newQty > 10) newQty = 10; // Limite máximo
    
    qtyElement.textContent = newQty;
}

// Adicionar ao carrinho
function addToCart(productId, productName, price) {
    const quantity = parseInt(document.getElementById(`qty-${productId}`).textContent);
    
    // Verificar se o produto já está no carrinho
    const existingItem = carrinho.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += quantity;
    } else {
        carrinho.push({
            id: productId,
            name: productName,
            price: price,
            quantity: quantity
        });
    }
    
    updateCarrinhoCount();
    
    // Feedback visual
    showMessage('Produto adicionado ao carrinho!', 'success');
    
    // Resetar quantidade para 1
    document.getElementById(`qty-${productId}`).textContent = '1';
}

// Atualizar contador do carrinho
function updateCarrinhoCount() {
    const totalItems = carrinho.reduce((total, item) => total + item.quantity, 0);
    document.getElementById('carrinho-count').textContent = totalItems;
}

// Atualizar display do carrinho
function updateCarrinhoDisplay() {
    const carrinhoItems = document.getElementById('carrinho-items');
    const totalPrice = document.getElementById('total-price');
    
    if (carrinho.length === 0) {
        carrinhoItems.innerHTML = '<p>Seu carrinho está vazio.</p>';
        totalPrice.textContent = '0,00';
        return;
    }
    
    let html = '';
    let total = 0;
    
    carrinho.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        html += `
            <div class="carrinho-item">
                <div>
                    <strong>${item.name}</strong><br>
                    R$ ${item.price.toFixed(2).replace('.', ',')} x ${item.quantity}
                </div>
                <div>
                    <span>R$ ${itemTotal.toFixed(2).replace('.', ',')}</span>
                    <button class="remove-item" onclick="removeFromCart(${index})">Remover</button>
                </div>
            </div>
        `;
    });
    
    carrinhoItems.innerHTML = html;
    totalPrice.textContent = total.toFixed(2).replace('.', ',');
}

// Remover do carrinho
function removeFromCart(index) {
    carrinho.splice(index, 1);
    updateCarrinhoCount();
    updateCarrinhoDisplay();
}

// Finalizar compra
function finalizarCompra() {
    if (carrinho.length === 0) {
        showMessage('Seu carrinho está vazio!', 'error');
        return;
    }
    
    // Simular processamento de pagamento
    const total = carrinho.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    // Aqui seria integrado com um gateway de pagamento real
    // Por exemplo: Stripe, PagSeguro, Mercado Pago, etc.
    
    showMessage(`Compra finalizada! Total: R$ ${total.toFixed(2).replace('.', ',')}. Em uma implementação real, você seria redirecionado para o pagamento.`, 'success');
    
    // Limpar carrinho
    carrinho = [];
    updateCarrinhoCount();
    updateCarrinhoDisplay();
    
    // Fechar modal
    document.getElementById('carrinho-modal').style.display = 'none';
    
    // Simular redirecionamento para pagamento
    setTimeout(() => {
        alert('Redirecionando para o gateway de pagamento...\n\nEm uma implementação real, aqui seria integrado com:\n- Stripe\n- PagSeguro\n- Mercado Pago\n- PayPal\n- Ou outro gateway de sua escolha');
    }, 1000);
}

// Processar agendamento
function processarAgendamento() {
    const formData = new FormData(document.getElementById('agendamento-form'));
    const agendamento = {
        servico: formData.get('servico-select'),
        data: formData.get('data-agendamento'),
        horario: formData.get('horario-agendamento'),
        nome: formData.get('nome-cliente'),
        telefone: formData.get('telefone-cliente')
    };
    
    // Validar se a data não é no passado
    const dataAgendamento = new Date(agendamento.data);
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    
    if (dataAgendamento < hoje) {
        showMessage('A data do agendamento não pode ser no passado!', 'error');
        return;
    }
    
    // Simular verificação de disponibilidade
    // Em uma implementação real, isso seria verificado no backend
    
    // Simular salvamento do agendamento
    console.log('Agendamento processado:', agendamento);
    
    showMessage(`Agendamento confirmado para ${agendamento.data} às ${agendamento.horario}. Entraremos em contato via WhatsApp para confirmar.`, 'success');
    
    // Fechar modal e limpar formulário
    document.getElementById('agendamento-modal').style.display = 'none';
    document.getElementById('agendamento-form').reset();
    
    // Simular envio de confirmação
    setTimeout(() => {
        alert(`Confirmação de Agendamento:\n\nServiço: ${getServiceName(agendamento.servico)}\nData: ${formatDate(agendamento.data)}\nHorário: ${agendamento.horario}\nCliente: ${agendamento.nome}\n\nEm uma implementação real, seria enviado:\n- Email de confirmação\n- SMS/WhatsApp\n- Integração com calendário\n- Notificação para o prestador de serviço`);
    }, 1000);
}

// Funções auxiliares
function getServiceName(serviceId) {
    const services = {
        'massagem': 'Massagem Relaxante',
        'reiki': 'Atendimento com Reiki',
        'aromaterapia': 'Sessão de Aromaterapia'
    };
    return services[serviceId] || serviceId;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

function showMessage(message, type) {
    // Remover mensagens existentes
    const existingMessages = document.querySelectorAll('.success-message, .error-message');
    existingMessages.forEach(msg => msg.remove());
    
    // Criar nova mensagem
    const messageDiv = document.createElement('div');
    messageDiv.className = type === 'success' ? 'success-message' : 'error-message';
    messageDiv.textContent = message;
    
    // Adicionar ao topo da página
    document.body.insertBefore(messageDiv, document.body.firstChild);
    
    // Remover após 5 segundos
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
    
    // Scroll para o topo para ver a mensagem
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Simulação de integração com plataformas externas
class IntegrationManager {
    // Simulação de integração com Calendly
    static integrateCalendly() {
        // Em uma implementação real, seria algo como:
        // Calendly.initInlineWidget({
        //     url: 'https://calendly.com/seu-usuario',
        //     parentElement: document.getElementById('calendly-container')
        // });
        console.log('Integração com Calendly simulada');
    }
    
    // Simulação de integração com Stripe
    static integrateStripe() {
        // Em uma implementação real, seria algo como:
        // const stripe = Stripe('pk_test_...');
        // const elements = stripe.elements();
        console.log('Integração com Stripe simulada');
    }
    
    // Simulação de integração com WhatsApp Business API
    static sendWhatsAppConfirmation(phoneNumber, message) {
        // Em uma implementação real, seria uma chamada para a API do WhatsApp
        console.log(`WhatsApp para ${phoneNumber}: ${message}`);
    }
}

// Funções para demonstrar integrações futuras
function demonstrarIntegracoes() {
    console.log('=== Demonstração de Integrações Futuras ===');
    
    // Simular integração com diferentes plataformas
    IntegrationManager.integrateCalendly();
    IntegrationManager.integrateStripe();
    IntegrationManager.sendWhatsAppConfirmation('(99) 99999-9999', 'Agendamento confirmado!');
    
    console.log('Todas as integrações foram simuladas. Veja o console para detalhes.');
}



// by lecter

